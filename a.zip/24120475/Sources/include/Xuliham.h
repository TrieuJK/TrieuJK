char* RemoveSpacesAroundParentheses(char* cal);
void reverse(char * arr1, char * arr2);
int compareLargeNumbers(const char* num1, const char* num2);
char* addPositiveNumbers(const char* num1, const char* num2);
char* PlusLargeNumbers(const char* num1, const char* num2);
char* subtractLargeNumbers(const char* num1, const char* num2);
char* divideLargeNumbers(const char* num1, const char* num2);
char* multiplyLargeNumbers(const char* num1, const char* num2);
char* PerDivAMul(char* cal, int& count, int& k);
char* PerPlusASub(char* cal, int count, int& k);
char* EvaluateExpression(char* expression);

