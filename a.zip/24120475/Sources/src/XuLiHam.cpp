#include<iostream>
#include<string.h>
#include"Xuliham.h"

using namespace std;

void reverse(char * arr1, char * arr2) {
    // Giảm arr2 để trỏ đến ký tự cuối cùng trong dãy
    --arr2;
    while (arr1 < arr2) {
        // Hoán đổi hai ký tự
        char temp = *arr1;
        *arr1 = *arr2;
        *arr2 = temp;

        // Tiến và lùi con trỏ
        ++arr1;
        --arr2;
    }
}

char* RemoveSpacesAroundParentheses(char* cal) {
    int len = strlen(cal);
    char* cleaned = new char[len + 1];
    int index = 0;

    for (int i = 0; i < len; i++) {
        if (cal[i] == '(') {
            // Kiểm tra nếu bên trong dấu ngoặc chỉ chứa số
            bool containsOperator = false;
            int j = i + 1;
            while (j < len && cal[j] != ')') {
                if (cal[j] == '+' || (cal[j] == '-' && cal[j + 1] == ' ') || cal[j] == '*' || cal[j] == '/') {
                    containsOperator = true;
                }
                j++;
            }

            // Nếu không chứa toán tử, bỏ qua dấu ngoặc
            if (!containsOperator) {
                i++; // Bỏ dấu '('
                while (i < len && cal[i] != ')') {
                    if (cal[i] != ' ') {
                        cleaned[index++] = cal[i];
                    }
                    i++;
                }
                continue; // Bỏ dấu ')'
            }

            // Nếu chứa toán tử, giữ dấu ngoặc và loại bỏ khoảng trắng thừa
            cleaned[index++] = '(';
            while (i + 1 < len && cal[i + 1] == ' ') {
                i++;
            }
        } else if (cal[i] == ')') {
            // Loại bỏ khoảng trắng trước dấu ')'
            while (index > 0 && cleaned[index - 1] == ' ') {
                index--;
            }
            cleaned[index++] = ')';
        } else {
            cleaned[index++] = cal[i];
        }
    }

    cleaned[index] = '\0';
    return cleaned;
}

char* PlusLargeNumbers(const char* num1, const char* num2) {
    bool isNegative1 = (num1[0] == '-');
    bool isNegative2 = (num2[0] == '-');
    const char* absNum1 = isNegative1 ? num1 + 1 : num1;
    const char* absNum2 = isNegative2 ? num2 + 1 : num2;

    if (isNegative1 == isNegative2) {
        char* result = addPositiveNumbers(absNum1, absNum2);
        if (isNegative1) {
            char* finalResult = new char[strlen(result) + 2];
            finalResult[0] = '-';
            strcpy(finalResult + 1, result);
            delete[] result;
            return finalResult;
        }
        return result;
    } else {
        int cmp = compareLargeNumbers(absNum1, absNum2);
        char* result;
        if (cmp >= 0) {
            result = subtractLargeNumbers(absNum1, absNum2);
            if (isNegative1) {
                char* finalResult = new char[strlen(result) + 2];
                finalResult[0] = '-';
                strcpy(finalResult + 1, result);
                delete[] result;
                return finalResult;
            }
        } else {
            result = subtractLargeNumbers(absNum2, absNum1);
            if (!isNegative1) {
                char* finalResult = new char[strlen(result) + 2];
                finalResult[0] = '-';
                strcpy(finalResult + 1, result);
                delete[] result;
                return finalResult;
            }
        }
        return result;
    }
}

char* addPositiveNumbers(const char* num1, const char* num2) {
    int len1 = strlen(num1), len2 = strlen(num2);
    int maxLen = max(len1, len2) + 1;
    char* result = new char[maxLen + 1];
    memset(result, '0', maxLen);
    result[maxLen] = '\0';

    int carry = 0, i = len1 - 1, j = len2 - 1, k = maxLen - 1;
    while (i >= 0 || j >= 0 || carry) {
        int sum = carry + (i >= 0 ? num1[i--] - '0' : 0) + (j >= 0 ? num2[j--] - '0' : 0);
        carry = sum / 10;
        result[k--] = (sum % 10) + '0';
    }

    char* finalResult = strdup(result + k + 1);
    delete[] result;
    return finalResult;
}

char* subtractLargeNumbers(const char* num1, const char* num2) {
    int comparison = compareLargeNumbers(num1, num2);
    bool isNegative = (comparison < 0);
    const char* larger = (isNegative ? num2 : num1);
    const char* smaller = (isNegative ? num1 : num2);

    int lenLarger = strlen(larger), lenSmaller = strlen(smaller);
    char* result = new char[lenLarger + 2];
    memset(result, '0', lenLarger + 1);
    result[lenLarger + 1] = '\0';

    int borrow = 0;
    int i = lenLarger - 1, j = lenSmaller - 1, k = lenLarger;
    while (i >= 0) {
        int diff = (larger[i--] - '0') - (j >= 0 ? (smaller[j--] - '0') : 0) - borrow;
        if (diff < 0) {
            diff += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        result[k--] = diff + '0';
    }

    char* finalResult = result + k + 1;
    if (isNegative) {
        *(--finalResult) = '-';
    }

    char* output = strdup(finalResult);
    delete[] result;
    return output;
}

int compareLargeNumbers(const char* num1, const char* num2) {
    while (*num1 == '0') num1++;
    while (*num2 == '0') num2++;

    int len1 = strlen(num1), len2 = strlen(num2);

    if (len1 != len2) return len1 > len2 ? 1 : -1;

    for (int i = 0; i < len1; i++) {
        if (num1[i] != num2[i]) {
            return num1[i] > num2[i] ? 1 : -1;
        }
    }

    return 0;
}

char* EvaluateExpression(char* expression) {
    while (isspace(*expression)) expression++;

    char* result = new char[1001];
    strcpy(result, "0");

    char current_op = '+';
    char number[1001] = {0};
    int num_index = 0;

    bool check = false;
    for(int i = 0; i < 1000; i++) {
        if (*expression == '-') {
            check = true;
            expression++;
            continue;
        }
        if (isdigit(*expression)) {
            number[num_index++] = *expression;
            expression++;
        } else if (*expression == ' ') {
            break;
        }
    }
    if (check == true) current_op = '-';

    if (result[0] == '-') {
        size_t subtemp = strlen(result);
        char* SubTemp = new char[subtemp];
        strcpy(SubTemp, result + 1);

        char* temp_result = (current_op == '+') ? subtractLargeNumbers(SubTemp, number) : PlusLargeNumbers(SubTemp, number);

        if (temp_result[0] == '-') {
            strcpy(result, temp_result);
        } else {
            strcpy(result + 1, temp_result);
            result[0] = '-';
        }

        delete[] temp_result;
        num_index = 0;
    } else {
        char* temp_result = (current_op == '+') ? PlusLargeNumbers(result, number) : subtractLargeNumbers(result, number);
        strcpy(result, temp_result);
        delete[] temp_result;
        num_index = 0;
    }

    while (*expression) {
        if (*expression == '+' || *expression == '-') {
            if (*expression == '-') {
                if (expression[2] == '-') {
                    current_op = '+';
                    expression++;
                    expression++;
                } else if (expression[2] == '+') {
                    current_op = '-';
                    expression++;
                    expression++;
                } else {
                    current_op = '-';
                }
                expression++;
            } else if (*expression == '+') {
                if (expression[2] == '-') {
                    current_op = '-';
                    expression++;
                    expression++;
                } else {
                    current_op = '+';
                }
                expression++;
            }
            continue;
        } else if (*expression == ' ') {
            expression++;
            continue;
        } else if (isdigit(*expression)) {
            number[num_index++] = *expression;
            expression++;

            if (*expression == ' ' || *expression == '\0') {
                number[num_index] = '\0';

                char* temp_result = (current_op == '+') ? PlusLargeNumbers(result, number) : subtractLargeNumbers(result, number);
                strcpy(result, temp_result);
                delete[] temp_result;
                num_index = 0;
            }
        }
    }

    if (num_index > 0) {
        number[num_index] = '\0';
        char* temp_result = (current_op == '+') ? PlusLargeNumbers(result, number) : subtractLargeNumbers(result, number);
        strcpy(result, temp_result);
        delete[] temp_result;
    }

    return result;
}

char* divideLargeNumbers(const char* num1, const char* num2) {
    if (strcmp(num2, "0") == 0) {
        std::cerr << "Error: Division by zero!\n";
        return nullptr;
    }
    if (compareLargeNumbers(num1, num2) < 0) {
        char* zero = new char[2];
        strcpy(zero, "0");
        return zero;
    }

    int Len1 = strlen(num1), Len2 = strlen(num2);
    char* result = new char[Len1 + 1];
    memset(result, '0', Len1);
    result[Len1] = '\0';

    char* temp = new char[Len1 + 1];
    strcpy(temp, "");

    int tempLen = 0;
    for (int i = 0; i < Len1; ++i) {
        temp[tempLen++] = num1[i];
        temp[tempLen] = '\0';

        while (tempLen > 1 && temp[0] == '0') {
            memmove(temp, temp + 1, tempLen--);
        }

        int count = 0;
        while (compareLargeNumbers(temp, num2) >= 0) {
            char* subResult = subtractLargeNumbers(temp, num2);
            strcpy(temp, subResult);
            delete[] subResult;
            ++count;
        }

        result[i] = count + '0';
    }

    char* finalResult = result;
    while (*finalResult == '0' && *(finalResult + 1)) ++finalResult;

    char* trimmed = new char[strlen(finalResult) + 1];
    strcpy(trimmed, finalResult);

    delete[] result;
    delete[] temp;
    return trimmed;
}

char* multiplyLargeNumbers(const char* num1, const char* num2){
    int len1 = strlen(num1);
    int len2 = strlen(num2);
    char* result = new char[len1 + len2 + 1];
    memset(result, '0', len1 + len2);
    result[len1 + len2] = '\0';

    for (int i = len1 - 1; i >= 0; --i) {
        int carry = 0;
        int n1 = num1[i] - '0';

        for (int j = len2 - 1; j >= 0; --j) {
            int n2 = num2[j] - '0';
            int sum = (n1 * n2) + (result[i + j + 1] - '0') + carry;
            carry = sum / 10;
            result[i + j + 1] = (sum % 10) + '0';
        }

        result[i] += carry;
    }

    int startIdx = 0;
    while (result[startIdx] == '0' && result[startIdx + 1]) {
        startIdx++;
    }

    char* trimmed = new char[strlen(result) - startIdx + 1];
    strcpy(trimmed, result + startIdx);

    delete[] result;
    return trimmed;
}

char* PerDivAMul(char* cal, int& count, int& k) {
    int h = k;

    if (h == 0) return cal;

    char temp1[100] = {};  // Số trước phép toán
    char temp2[100] = {};  // Số sau phép toán

    int leftStart = h - 2, rightStart = h + 2;

    // Lấy số trước phép toán
    int idx1 = 0;
    bool check1 = false;
    while (leftStart >= 0 && cal[leftStart] != ' ' && cal[leftStart] != '(') {
        if (cal[leftStart] == '-' && cal[leftStart -1] == ' ') {
            leftStart--;
            check1 = true;
            continue;  // Bỏ qua số 0 không cần thiết
        }
        temp1[idx1++] = cal[leftStart--];
    }
    temp1[idx1] = '\0';
    reverse(temp1, temp1 + idx1);

    // Lấy số sau phép toán
    int idx2 = 0;
    bool check2 = false;
    while (rightStart < count && cal[rightStart] != ' ' && cal[rightStart] != ')') {
        if(cal[rightStart] == '-'){
            rightStart++;
            check2 = true;
            continue;
        }
        temp2[idx2++] = cal[rightStart++];
    }
    temp2[idx2] = '\0';

    // Thực hiện phép toán
    char* result = nullptr;
    if (cal[h] == '*') {
        result = multiplyLargeNumbers(temp1, temp2);
    } else if (cal[h] == '/') {
        result = divideLargeNumbers(temp1, temp2);
    }

    if (result) {
      int resultLen = strlen(result);

      // Adjust replaceLength considering potential negative signs before and after
      int leftNegativeOffset = check1 ? 1 : 0;  // For `temp1` negative sign
      int rightNegativeOffset = check2 ? 1 : 0; // For `temp2` negative sign
      // Total number of characters replaced includes space & negative signs
      int replaceLength = idx1 + 1 + leftNegativeOffset + idx2 + 1 + rightNegativeOffset;

      // Calculate new total length for updated expression
      int newLen = count - replaceLength + resultLen;

      // Allocate memory for updated expression
      char* updatedExpression = new char[newLen + 1];

      // Copy the part before operation
      strncpy(updatedExpression, cal, leftStart + 1);
      int copyOffset = leftStart + 1;

      // Handle negative signs appropriately
      if (check1 && !check2 || !check1 && check2) {
          updatedExpression[copyOffset++] = '-';
      }

      // Append the result of the operation
      strcpy(updatedExpression + copyOffset, result);
      copyOffset += resultLen;

      // Copy the remaining part of the original expression
      strcpy(updatedExpression + copyOffset, cal + rightStart);

      // Clean up and update variables
      delete[] cal;
      cal = updatedExpression;
      count = strlen(cal);
      delete[] result;
    }

    // Cập nhật vị trí mới sau dấu toán
    k = h + 1;

    return cal;
}

char* PerPlusASub(char* cal, int count, int& k) {
    int gar = k;
    int m = 0;  // Số phép toán tìm thấy
    int arr[100] = {0};  // Lưu vị trí của các phép toán
    int allocatedSize = 100;  // Kích thước bộ nhớ ban đầu cho finalResult
    char* finalResult = new char[allocatedSize]();
    finalResult[0] = '\0';  // Khởi tạo chuỗi rỗng

    // Tìm vị trí của dấu đóng ngoặc ')'
    for (int j = k + 1; j < count; j++) {
        if (cal[j] == ')') {
            k = j;  // Cập nhật vị trí
            break;
        }
    }

    // Tìm các phép toán cộng/trừ trong ngoặc
    for (int h = gar + 1; h < k; h++) {
        if (cal[h] == '+' || (cal[h] == '-' && cal[h + 1] == ' ')) {
            arr[m++] = h;
        }
    }

    // Trường hợp trong ngoặc chỉ có một số (không có phép toán)
    if (m == 0) {
        int digitCount = 0;
        for (int i = gar + 1; i < k; i++) {
            if (isdigit(cal[i])) {
                digitCount++;
            }
        }

        // Sao chép số vào kết quả
        char* lastresult = new char[digitCount + 1]();
        int Lcount = 0;
        for (int i = gar + 1; i < k; i++) {
            if (isdigit(cal[i])) {
                lastresult[Lcount++] = cal[i];
            }
        }
        lastresult[Lcount] = '\0';
        return lastresult;
    }

    // Xử lý các phép toán trong ngoặc
    char* result = nullptr;  // Kết quả tính toán tạm thời
    for (int a = 0; a < m; a++) {
        if (arr[a] != 0) {
            int h = arr[a];  // Vị trí của phép toán hiện tại
            char temp1[1000] = {};
            char temp2[1000] = {};
            int around1 = 0, around2 = 0;
            bool unk1 = false, unk2 = false;

            // Lấy số bên trái phép toán
            for (int t = h - 2; t >= gar && cal[t] != '(' && cal[t] != ' '; t--) {
                if (cal[t] == '-') {
                    unk1 = true;
                    continue;
                }
                temp1[around1++] = cal[t];
            }
            temp1[around1] = '\0';
            reverse(temp1, temp1 + around1);

            // Lấy số bên phải phép toán
            for (int t = h + 2; t < k && cal[t] != ')' && cal[t] != ' '; t++) {
                if (cal[t] == '-') {
                    unk2 = true;
                    continue;
                }
                temp2[around2++] = cal[t];
            }
            temp2[around2] = '\0';

            // Phép toán hiện tại
            char operation = cal[h];
            bool checkOpe = false, checkdau = false;

            // Xử lý dấu và phép toán
            if (result == nullptr) {
                if (operation == '+') {
                    if (!unk1 && unk2) {
                        operation = '-';
                    } else if (unk1 && !unk2) {
                        std::swap(temp1, temp2);
                        operation = '-';
                    } else if (unk1 && unk2) {
                        checkdau = true;
                    }
                } else if (operation == '-') {
                    if (!unk1 && unk2) {
                        operation = '+';
                        checkdau = true;
                    } else if (unk1 && !unk2) {
                        operation = '+';
                    } else if (unk1 && unk2) {
                        operation = '-';
                        std::swap(temp1, temp2);
                    }
                }

                // Tính toán dựa trên phép toán
                if (operation == '+') {
                    result = PlusLargeNumbers(temp1, temp2);
                    if (checkdau) {
                        char* temp = new char[strlen(result) + 2];
                        temp[0] = '-';
                        strcpy(temp + 1, result);
                        delete[] result;
                        result = temp;
                    }
                } else if (operation == '-') {
                    if (around1 < around2 || checkOpe) {
                        result = subtractLargeNumbers(temp2, temp1);
                        char* temp = new char[strlen(result) + 2];
                        temp[0] = '-';
                        strcpy(temp + 1, result);
                        delete[] result;
                        result = temp;
                    } else {
                        result = subtractLargeNumbers(temp1, temp2);
                    }
                }

                // Cập nhật finalResult
                int neededSize = strlen(finalResult) + strlen(result) + 2;
                if (neededSize > allocatedSize) {
                    while (neededSize > allocatedSize) {
                        allocatedSize *= 2;
                    }
                    char* temp = new char[allocatedSize];
                    strcpy(temp, finalResult);
                    delete[] finalResult;
                    finalResult = temp;
                }
                strcpy(finalResult, result);
            }
        }
    }

    // Trả về kết quả cuối cùng
    char* optimizedResult = new char[strlen(finalResult) + 1];
    strcpy(optimizedResult, finalResult);
    delete[] finalResult;
    return optimizedResult;
}

