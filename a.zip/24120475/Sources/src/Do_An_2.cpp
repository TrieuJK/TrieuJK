    #include <iostream>
    #include<string.h>
    #include"Xuliham.h"
    using namespace std;
int main() {
    int line = 0;
    FILE* file;
    file = fopen("data/input.txt", "r");
    FILE * infile;
    infile = fopen("data/output.txt", "w");
    char* cal = new char[1000]();  // Original string

    if (file == NULL) {
        cerr << "Can't open the file." << endl;
        return 1;
    }

    while (fgets(cal, 1000, file)) {
        line++;
        size_t length = strlen(cal);
        if (length > 0 && cal[length - 1] == '\n') {
            cal[length - 1] = '\0';  // Replace '\n' with null character
        }
        // check invalid charater
        bool tester = false;
        for(int i = 0; i < length - 1;i++){
            if (!isdigit(cal[i]) && cal[i] != '+' && cal[i] != '-' && cal[i] != '/' &&
                cal[i] != '*' && cal[i] != '(' && cal[i] != ')' && cal[i] != ' ') {
                fprintf(infile,"Appear invalid charater in line: %d\n", line);
                tester = true;
                break;
                }
        }
        if(tester){
            continue;
        }

        //check case calculator is not reasonable
        bool Dive = 0, Multi = 0, Pls = 0, Subs = 0;
        for(int i = 0; i < length; i++){
            if( cal[i] == '+' && cal[i+1] == '+') Pls = true;
            else if(cal[i] == '-' && cal[i+1] == '-') Subs = true;
            else if(cal[i] == '*' && cal[i+1] == '*') Multi = true;
            else if(cal[i] == '/' && cal[i+1] == '/') Dive = true;
        }
        if(Pls || Subs || Multi || Dive){
            fprintf(infile,"invalid calculator in line: %d\n", line);
            continue;
        }

        //check case parathesis is not same
        int Paraleft = 0, Pararight = 0;
        for(int i = 0; i < length; i++){
            if(cal[i] == '(') Paraleft++;
            else if(cal[i] == ')') Pararight++;
        }
        if(Paraleft != Pararight){
            fprintf(infile,"invalid Parathesis in line: %d\n", line);
            continue;
        }        

        // check format
        bool CheckFormat = false;
        for (int i = 0; i < length; i++) {
        // Check for multiple spaces
        if (cal[i] == ' ' && cal[i + 1] == ' ') {
            fprintf(infile, "invalid format in line: %d (multiple spaces)\n", line);
            CheckFormat = true;
        }

        // Check for invalid spacing around operators
        if ((cal[i] == '+' || cal[i] == '-' || cal[i] == '*' || cal[i] == '/') &&
            (i == 0 || cal[i - 1] != ' ' || cal[i + 1] != ' ')) {
            if (!(cal[i] == '-' && isdigit(cal[i + 1]) && (i == 0 || cal[i - 1] == '(' || cal[i - 1] == ' '))) {
                fprintf(infile, "invalid format in line: %d (missing space around operator '%c')\n", line, cal[i]);
                CheckFormat = true;
            }
        }
         // Check for digits improperly separated by spaces (e.g., "12 34")
        if (isdigit(cal[i]) && cal[i + 1] == ' ' && isdigit(cal[i + 2])) {
            fprintf(infile, "invalid format in line: %d (digits separated by space)\n", line);
            CheckFormat = true;
        }
    }
        if(CheckFormat){
            continue;
        }

        int count = strlen(cal);  // String length
        int k = 3;  // Assuming there are k operations

        // Call function to perform multiplication or division
        for (int i = 0; i < count; i++) {
            if (cal[i] == '(') {
                for (int j = i + 1; j < count; j++) {
                    if (cal[j] == ')' && cal[j + 1]) {
                        i = j;  // Update position i
                        break;
                    } else if ((cal[j] == '/' || cal[j] == '*') && cal[j] != '\0') {
                        k = j;
                        cal = PerDivAMul(cal, count, k);
                        j = 0;
                    }
                }
            } else if (cal[i] == '*' || cal[i] == '/') {  // Added condition for '*' and '/'
                k = i;
                // Check for * (a + b) * (c + d)
                if (cal[i - 2] == ')' || cal[i + 2] == '(') {
                    continue;
                }
                cal = PerDivAMul(cal, count, k);
                i = 0;
            }
        }

        // Handle spaces around parentheses
        char* cleanedCal = RemoveSpacesAroundParentheses(cal);
        int len1 = strlen(cleanedCal) + 1;
        char* as = new char[len1 + 8];
        as[0] = '\0';  // Initialize empty string
        char* res = nullptr;
        int krs;
        for (int i = 0; i < len1 - 1; i++) {
            if (cleanedCal[i] == '(') {  // If encountering '('
                krs = i;
                res = PerPlusASub(cleanedCal, strlen(cleanedCal), krs);  // Process expression inside parentheses

                int len = strlen(res) + 1;
                char* temp = new char[len1 + len];  // Create a new memory block for combined string
                strcpy(temp, as);
                strcat(temp, res);  // Append result of Per function
                delete[] as;
                as = temp;  // Update pointer to new memory

                // Update position to continue processing
                i = krs;
            } else {
                // Copy non-parenthesis characters to result string
                int lenAs = strlen(as);
                as[lenAs] = cleanedCal[i];
                as[lenAs + 1] = '\0';  // Ensure null-termination
            }
        }
        // Process multiplication and division outside parentheses
        int Las = strlen(as);
        for (int i = 0; i < Las; i++) {
            if (as[i] == '*' || as[i] == '/') {
                int tel = i;
                as = PerDivAMul(as, Las, tel);
                i = 0;
            }
        }

        char* lastResult = EvaluateExpression(as);
        // Print final result
        fprintf(infile,"%s\n",lastResult);
        // Free allocated memory
        delete[] as;
        delete[] res;
        delete[] lastResult;
        delete[] cleanedCal;
        delete[] cal;  // Free cal memory
        cal = new char[1000]();
    }
    cout << "Sucessfully" << endl;
    fclose(file);
    fclose(infile);
    delete[] cal;  // Free memory for cal
    return 0;
}